# Electroknit App

An electron app for knitting machines. Currently works with [knitic](http://www.knitic.com) boards. Future plans to support OpenKnit and other platforms. Electron app based on https://github.com/chentsulin/electron-react-boilerplate

![Electroknit App](http://i.imgur.com/9AxJI3u.png)

## Package

```bash
npm run package
```

To package apps for all platforms:

```bash
npm run package-all
```

## Questions?

http://www.twitter.com/korevec